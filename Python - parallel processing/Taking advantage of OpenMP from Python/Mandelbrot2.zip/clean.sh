#!/bin/sh -x
rm -f *.o *.so *~
